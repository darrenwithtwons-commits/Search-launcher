package com.google.android.nanolauncher.model

/**
 * Models parsed user intents from Gemini Nano on-device model.
 */
sealed class NanoIntent(
    val actionLabel: String,
    val detailText: String
) {
    data class LaunchApp(val appName: String) : NanoIntent(
        actionLabel = "Open App",
        detailText = "Launch $appName immediately"
    )

    data class SendSms(val contact: String, val message: String) : NanoIntent(
        actionLabel = "Send SMS",
        detailText = "To $contact: \"$message\""
    )

    data class CallContact(val contact: String) : NanoIntent(
        actionLabel = "Phone Call",
        detailText = "Dial $contact"
    )

    data class SetAlarm(val timeString: String) : NanoIntent(
        actionLabel = "Set Alarm",
        detailText = "Alarm for $timeString"
    )

    data class ToggleSetting(val settingName: String, val enabled: Boolean) : NanoIntent(
        actionLabel = "Device Setting",
        detailText = "$settingName ${if (enabled) "ON" else "OFF"}"
    )

    data class AnswerQuestion(val question: String, val answer: String) : NanoIntent(
        actionLabel = "Gemini Nano Answer",
        detailText = answer
    )
}