package com.google.android.nanolauncher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PureBlackColorScheme = darkColorScheme(
    background = Color.Black,
    surface = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    primary = Color.White
)

@Composable
fun NanoLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PureBlackColorScheme,
        content = content
    )
}
