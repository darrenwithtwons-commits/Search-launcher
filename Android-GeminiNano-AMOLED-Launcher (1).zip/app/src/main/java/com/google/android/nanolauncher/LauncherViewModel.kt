package com.google.android.nanolauncher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.nanolauncher.action.ActionDispatcher
import com.google.android.nanolauncher.gemini.GeminiNanoClient
import com.google.android.nanolauncher.model.NanoIntent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val geminiClient = GeminiNanoClient(application)
    private val dispatcher = ActionDispatcher(application)

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _intentState = MutableStateFlow<NanoIntent?>(null)
    val intentState: StateFlow<NanoIntent?> = _intentState.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    fun onQueryChanged(newQuery: String) {
        _query.value = newQuery
        if (newQuery.isEmpty()) {
            _intentState.value = null
        }
    }

    fun onSubmitQuery() {
        val currentQuery = _query.value.trim()
        if (currentQuery.isEmpty()) return

        viewModelScope.launch {
            _isExecuting.value = true
            val parsedIntent = geminiClient.processQuery(currentQuery)
            _isExecuting.value = false

            if (parsedIntent is NanoIntent.AnswerQuestion) {
                // Show the answer card directly below the bar
                _intentState.value = parsedIntent
            } else {
                // Execute device actions (open app, text, call, flashlight) immediately
                dispatcher.execute(parsedIntent)
                _query.value = ""
                _intentState.value = null
            }
        }
    }

    fun executeIntent(intent: NanoIntent) {
        dispatcher.execute(intent)
        _query.value = ""
        _intentState.value = null
    }
}
