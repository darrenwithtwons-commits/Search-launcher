package com.google.android.nanolauncher.action

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.widget.Toast
import com.google.android.nanolauncher.model.NanoIntent

/**
 * Dispatches parsed Gemini Nano intents directly into Android 17 OS actions.
 */
class ActionDispatcher(private val context: Context) {

    fun execute(intent: NanoIntent) {
        when (intent) {
            is NanoIntent.LaunchApp -> launchAppByName(intent.appName)
            is NanoIntent.SendSms -> sendSms(intent.contact, intent.message)
            is NanoIntent.CallContact -> callContact(intent.contact)
            is NanoIntent.SetAlarm -> setAlarm(intent.timeString)
            is NanoIntent.ToggleSetting -> toggleSetting(intent.settingName, intent.enabled)
            is NanoIntent.AnswerQuestion -> {
                // Answers are displayed directly in the Compose UI
            }
        }
    }

    private fun launchAppByName(appName: String) {
        val pm = context.packageManager
        val launchIntent = pm.getInstalledApplications(0).firstOrNull { appInfo ->
            pm.getApplicationLabel(appInfo).toString().equals(appName, ignoreCase = true)
        }?.let { appInfo ->
            pm.getLaunchIntentForPackage(appInfo.packageName)
        }

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            Toast.makeText(context, "App '$appName' not found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resolvePhoneNumber(contactName: String): String {
        val resolver = context.contentResolver
        val selection = "${android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val targets = if (contactName.equals("mother", ignoreCase = true) ||
            contactName.equals("mom", ignoreCase = true)
        ) {
            arrayOf("%Mom%", "%Mother%", "%Ashley%")
        } else {
            arrayOf("%$contactName%")
        }

        for (target in targets) {
            resolver.query(
                android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER),
                selection,
                arrayOf(target),
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    return cursor.getString(0) ?: ""
                }
            }
        }
        return ""
    }

    private fun sendSms(contact: String, message: String) {
        val number = resolvePhoneNumber(contact)
        val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:$number")
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(smsIntent)
    }

    private fun callContact(contact: String) {
        val number = resolvePhoneNumber(contact)
        val callIntent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse(if (number.isNotEmpty()) "tel:$number" else "tel:")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(callIntent)
    }

    private fun setAlarm(time: String) {
        val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_MESSAGE, "Gemini Nano Alarm")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(alarmIntent)
    }

    private fun toggleSetting(setting: String, enabled: Boolean) {
        if (setting == "flashlight") {
            try {
                val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val cameraId = cameraManager.cameraIdList[0]
                cameraManager.setTorchMode(cameraId, enabled)
            } catch (e: Exception) {
                Toast.makeText(context, "Flashlight: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}