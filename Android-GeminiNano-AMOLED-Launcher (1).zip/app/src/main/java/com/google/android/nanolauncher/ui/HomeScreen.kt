package com.google.android.nanolauncher.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.nanolauncher.LauncherViewModel
import com.google.android.nanolauncher.model.NanoIntent

/**
 * Single-Bar Monochrome UI (Compose)
 * Pure AMOLED black (#000000) screen with a single OutlinedTextField
 */
@Composable
fun HomeScreen(
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val query by viewModel.query.collectAsState()
    val intentState by viewModel.intentState.collectAsState()
    val isExecuting by viewModel.isExecuting.collectAsState()

    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        // Automatically request keyboard on home launch
        focusRequester.requestFocus()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black) // Pure AMOLED #000000
            .imePadding()            // Adapts gracefully when soft keyboard opens
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Optional: Result / Gemini Nano stream card above or below bar
            AnimatedVisibility(
                visible = intentState != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                intentState?.let { intent ->
                    NanoResponseCard(
                        intent = intent,
                        onExecute = { viewModel.executeIntent(intent) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // The Single Minimalist OutlinedTextField Search Bar
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.onQueryChanged(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .focusRequester(focusRequester),
                shape = RoundedCornerShape(32.dp),
                placeholder = {
                    Text(
                        text = "Ask or command...",
                        color = Color(0xFF666666),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Normal
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Search
                ),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        viewModel.onSubmitQuery()
                        keyboardController?.hide()
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.Black,
                    unfocusedContainerColor = Color.Black,
                    focusedBorderColor = Color.White,
                    unfocusedBorderColor = Color(0xFF262626),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Color.White
                )
            )
        }
    }
}

@Composable
fun NanoResponseCard(
    intent: NanoIntent,
    onExecute: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF333333), RoundedCornerShape(16.dp))
            .clickable { onExecute() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0A0A))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = intent.actionLabel,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = intent.detailText,
                color = Color(0xFFAAAAAA),
                fontSize = 13.sp
            )
        }
    }
}