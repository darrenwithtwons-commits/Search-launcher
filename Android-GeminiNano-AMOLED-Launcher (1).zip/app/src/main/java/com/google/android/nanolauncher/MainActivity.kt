package com.google.android.nanolauncher

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.nanolauncher.ui.HomeScreen
import com.google.android.nanolauncher.ui.theme.NanoLauncherTheme

/**
 * Android 17 Minimalist Launcher Entry Activity
 * Pure AMOLED black window with edge-to-edge layout and hidden system bars.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Android 17 edge-to-edge layout
        enableEdgeToEdge()

        // 2. Set pure AMOLED black (#000000) window background
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))

        // 3. Hide status and navigation bars for pure monochrome immersion
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(
            WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars()
        )

        // 4. Mount Jetpack Compose Single-Bar Monochrome UI
        setContent {
            NanoLauncherTheme {
                HomeScreen(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Re-enforce pure immersion when returning to home screen
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.hide(
            WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars()
        )
    }
}