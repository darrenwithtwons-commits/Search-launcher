package com.google.android.nanolauncher.gemini

import android.content.Context
import com.google.android.nanolauncher.model.NanoIntent
import com.google.mlkit.genai.prompt.Generation

class GeminiNanoClient(private val context: Context) {

    private val generativeModel by lazy { Generation.getClient() }

    suspend fun processQuery(query: String): NanoIntent {
        val lower = query.trim().lowercase()
        return when {
            lower.startsWith("open ") || lower.startsWith("launch ") -> {
                val app = query.substringAfter(" ").trim()
                NanoIntent.LaunchApp(app)
            }
            lower.startsWith("text ") || lower.startsWith("message ") -> {
                val parts = query.substringAfter(" ").trim().split(" ", limit = 2)
                val contact = parts.getOrNull(0) ?: ""
                val msg = parts.getOrNull(1) ?: ""
                NanoIntent.SendSms(contact, msg)
            }
            lower.startsWith("call ") -> {
                val contact = query.substringAfter("call ").trim()
                NanoIntent.CallContact(contact)
            }
            lower.contains("flashlight") -> {
                val turnOff = lower.contains("off")
                NanoIntent.ToggleSetting("flashlight", !turnOff)
            }
            else -> {
                try {
                    val response = generativeModel.generateContent(
                        "Answer concisely in 1-3 short sentences: $query"
                    )
                    val text = response.candidates.firstOrNull()?.text?.trim()
                        ?: "No response generated."
                    NanoIntent.AnswerQuestion(query, text)
                } catch (e: Exception) {
                    NanoIntent.AnswerQuestion(
                        query,
                        "AICore warming up or unavailable: ${e.localizedMessage}"
                    )
                }
            }
        }
    }
}
