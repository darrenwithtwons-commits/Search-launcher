# Android 17 Gemini Nano AMOLED Launcher
An ultra-minimalist home screen launcher consisting EXCLUSIVELY of a single search bar on pure AMOLED black (#000000).

## Highlights
- **100% Pure AMOLED Black**: #000000 canvas with hidden status and navigation bars.
- **On-Device Gemini Nano**: Powered by Android 17 AICore foundation model.
- **Zero Distractions**: No app grid, no widgets, no notification badges.
- **Direct OS Intent Execution**: Instant app launch, SMS, phone calls, settings, alarms.

## Requirements
- Android Studio Ladybug / Iguana or later
- Android SDK 35 (Android 15 / 16)
- Device running Android 14+ (AICore recommended)
